package com.easywash;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EasyWashApplication {

	public static void main(String[] args) {
		SpringApplication.run(EasyWashApplication.class, args);
	}

}
