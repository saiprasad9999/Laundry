package com.easywash;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EasyWashApplicationTests {

	@Test
	void contextLoads() {
	}

}
